import 'package:firebase_lesson/model/post_model.dart';
import 'package:firebase_lesson/pages/details_page.dart';
import 'package:firebase_lesson/service/auth_service.dart';
import 'package:firebase_lesson/service/rtdb_service.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Post> items = [];

  _apiPostList() async {
    var list = await RTDBService.getPost();
    setState(() {
      items = list;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _apiPostList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueAccent,
        title: Text(
          "Home Page",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        actions: [
          IconButton(
              onPressed: () {
                AuthService.signOut(context);
              },
              icon: Icon(
                Icons.logout,
                color: Colors.red,
              ))
        ],
      ),
      body: ListView.builder(
        itemBuilder: (BuildContext ctx, int index) {
          return Card(
            child: Container(
              height: 66,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        items[index].firstName!,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 22,
                        ),
                      ),
                      SizedBox(
                        width: 12,
                      ),
                      Text(
                        items[index].lastName!,
                        style: TextStyle(color: Colors.black, fontSize: 22),
                      ),
                    ],
                  ),
                  Text(
                    items[index].about!,
                    style: TextStyle(color: Colors.black, fontSize: 22),
                  ),
                ],
              ),
            ),
          );
        },
        itemCount: items.length,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) {
            return DetailsPage();
          }));
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
