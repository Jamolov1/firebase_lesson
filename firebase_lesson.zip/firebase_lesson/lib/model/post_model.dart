class Post {
  String? firstName;
  String? lastName;
  String? about;

  Post({this.firstName, this.lastName, this.about});

  Post.fromJson(Map<String, dynamic> json)
      : firstName = json["firstName"],
        lastName = json["lastName"],
        about = json["about"];

  Map<String, dynamic> toJson() =>
      {"firstName": firstName, "lastName": lastName, "about": about};
}
