package com.example.firebase_lesson

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
